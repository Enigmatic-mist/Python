import numpy as np
import sys
import os
from collections import defaultdict
from typing import Dict, Tuple


def evalSpice(fname: str) -> Tuple[Dict, Dict]:
    """
    Evaluates a SPICE circuit file to solve for node voltages and current sources.

    Parameters:
    fname (str): The path to the SPICE circuit file.

    Returns:
    tuple: A tuple containing:
        - node_volt (dict): A dictionary mapping node names to their voltages and voltage sources.
        - curr_vs (dict): A dictionary mapping voltage source names to the currents through them.

    Raises:
    FileNotFoundError: If the file does not exist.
    ValueError: If the file format is incorrect or if the matrix is singular.
    TypeError: If the magnitude of element is not provided correctly
    """
    # Check if the given file name is valid
    if not os.path.isfile(fname):
        raise FileNotFoundError("Please give the name of a valid SPICE file as input")
        sys.exit()

    # Dictionary to hold element connections and values
    elems = defaultdict(list)

    # Variables and counters for processing
    m = 0  # Variable to indicate whether we are within the .circuit section
    i = 0  # Counter for voltage sources
    j = 1  # Index for node numbering
    n = 0  # Variable to check if the circuit ends properly

    # Set to store unique nodes
    nodes = set()

    # Open and read the SPICE file
    with open(fname) as fp:
        for line in fp:
            words_1 = line.split("#")  # Split the line at comments
            words = words_1[0].split()  # Take the part before the comment

            # Check for the start of the circuit section
            if ".circuit" in words:
                m = 1
                n = 1
                continue

            # Check for the end of the circuit section
            elif ".end" in words:
                m = 0
                n = 2
                break

            # Process lines within the .circuit section
            elif m == 1:
                key = words[
                    0
                ]  # Element type (resistor, voltage source, current source)

                # Add element connection nodes
                elems[key].append(words[1])
                elems[key].append(words[2])
                nodes.add(words[1])
                nodes.add(words[2])

                # Process voltage sources
                if key[0] == "V":
                    try:
                        float(words[4])  # Ensure the value is a float or int
                        elems[key].append(words[4])
                        i += 1
                        nodes.add(key)
                        if len(words) != 5:  # Check for correct number of parameters
                            raise ValueError("Malformed circuit")
                    except:
                        raise TypeError("Malformed circuit")
                        sys.exit()

                # Process resistors
                elif key[0] == "R":
                    try:
                        float(words[3])  # Ensure the value is a float or int
                        elems[key].append(words[3])
                        if len(words) != 4:  # Check for correct number of parameters
                            raise ValueError("Malformed circuit")
                    except:
                        raise TypeError("Malformed")
                        sys.exit()

                # Process current sources
                elif key[0] == "I":
                    try:
                        float(words[4])  # Ensure the value is a float or int
                        elems[key].append(words[4])
                        if len(words) != 5:  # Check for correct number of parameters
                            raise ValueError("Malformed circuit")
                    except:
                        raise TypeError("Malformed circuit")
                        sys.exit()

                # Raise an error for unsupported elements
                else:
                    raise ValueError("Only V, I, R elements are permitted")

        # Check if the circuit has .circuit and .end
        if n != 2:
            raise ValueError("Malformed circuit file")

        # Create a mapping of nodes to indices
        kcl_nodes = defaultdict(str)
        for node in nodes:
            if node[0] == "n" or node[0].isdigit():
                kcl_nodes[node] = j
                j += 1
            elif node == "GND":
                kcl_nodes["GND"] = 0

        # Include voltage sources in the node mapping
        for node in nodes:
            if node[0] == "V":
                kcl_nodes[node] = j
                j += 1

        # Dimension of the matrix
        mat_dim = int(len(nodes))
        var_mat = np.zeros((mat_dim, mat_dim))  # Variable matrix (conductance matrix)
        curr_mat = np.zeros((mat_dim, 1))  # Current matrix

        # Generate the matrices based on element types
        for key in elems:
            n1 = elems[key][0]
            n2 = elems[key][1]
            index_n1 = int(kcl_nodes[n1])
            index_n2 = int(kcl_nodes[n2])

            if key[0] == "R":
                # Update coefficient matrix for resistors
                var_mat[index_n1][index_n1] += 1 / float(elems[key][2])
                var_mat[index_n1][index_n2] += -1 / float(elems[key][2])
                var_mat[index_n2][index_n2] += 1 / float(elems[key][2])
                var_mat[index_n2][index_n1] += -1 / float(elems[key][2])

            elif key[0] == "V":
                # Update matrices for voltage sources
                index_V = kcl_nodes[key]
                var_mat[index_V][index_n1] += 1
                var_mat[index_V][index_n2] += -1
                var_mat[index_n1][index_V] += 1
                var_mat[index_n2][index_V] += -1
                curr_mat[index_V][0] += float(elems[key][2])

            elif key[0] == "I":
                # Update current matrix for current sources
                curr_mat[index_n1][0] += -float(elems[key][2])
                curr_mat[index_n2][0] += float(elems[key][2])

        # Remove the rows and columns corresponding to the ground node
        var_mat = np.delete(var_mat, (0), axis=0)
        var_mat = np.delete(var_mat, (0), axis=1)
        curr_mat = np.delete(curr_mat, (0), axis=0)

        # Check if the variable matrix is singular
        if np.linalg.matrix_rank(var_mat) < mat_dim - 1:
            raise ValueError("Circuit error: no solution")

        # Solve the system of equations
        val_mat = np.linalg.solve(var_mat, curr_mat)

        # Calculate node voltages and currents
        node_volt = defaultdict(float)
        curr_vs = defaultdict(float)
        for node in nodes:
            if node[0] == "V":
                curr_vs[node] = val_mat[int(kcl_nodes[node]) - 1]
            elif node[0] == "n" or node[0].isdigit():
                node_volt[node] = val_mat[int(kcl_nodes[node]) - 1]
            elif node == "GND":
                node_volt[node] = 0.0

        return node_volt, curr_vs
